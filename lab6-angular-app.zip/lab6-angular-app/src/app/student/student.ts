export interface Student {
  name: string;
}
