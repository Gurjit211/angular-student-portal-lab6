import { Injectable } from '@angular/core';
import { Student } from './student';

@Injectable({
  providedIn: 'root'
})
export class StudentService {
  getStudent(): Student {
    return { name: 'Gurjit Singh Sidhu' };
  }
}
