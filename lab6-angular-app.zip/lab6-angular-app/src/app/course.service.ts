import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CourseService {
  getCourses(): string[] {
    return [
      'Web Development Framework 2',
      'Android Development 2',
      'Big Data2',
      'Business Intelligence'
    ];
  }
}
