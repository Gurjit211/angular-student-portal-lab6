import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms'; // ✅ For template-driven forms

import { StudentComponent } from './student/student.component';
import { RegisterButtonComponent } from './register-button/register-button.component';
import { CourseListComponent } from './course-list/course-list.component';

import { StudentService } from './student/student.service';
import { CourseService } from './course.service';
import { Student } from './student/student';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule, // ✅ for ngModel
    StudentComponent,
    RegisterButtonComponent,
    CourseListComponent
  ],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [CourseService, StudentService]
})
export class AppComponent {
  title = 'Angular Student Portal';
  student!: Student;
  courses: string[] = [];
  isRegistered = false;

  feedback = {
    name: '',
    comments: ''
  };

  submitted = false;

  constructor(
    private courseService: CourseService,
    private studentService: StudentService
  ) {
    this.courses = this.courseService.getCourses();
    this.student = this.studentService.getStudent();
  }

  toggleRegistration() {
    this.isRegistered = !this.isRegistered;
  }

  submitForm() {
    this.submitted = true;
  }
}
