import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-register-button',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './register-button.component.html',
  styleUrls: ['./register-button.component.css']
})
export class RegisterButtonComponent {
  @Input() isRegistered = false;
  @Output() registerToggle = new EventEmitter<void>();

  toggle() {
    this.registerToggle.emit();
  }
}
